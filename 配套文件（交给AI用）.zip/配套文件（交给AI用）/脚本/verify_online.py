#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
线上抽检：状态码 + 红线词扫描 + 页面关键文本断言

用法
    python3 verify_online.py --config check.config.json [--retries 6] [--delay 20]

流程
    1) 逐个路径请求，断言 HTTP 200；
    2) 每个页面下载后跑红线词全文扫描（Title / 注释 / JS 字符串全在内，只看正文会漏）；
    3) 断言 must 全部命中、mustNot 全部未命中；
    4) 任一路径失败时按 --delay 秒重试，用于等 GitHub Pages 的 CDN 生效。

退出码
    0 全部通过 / 1 有失败项
"""

import argparse
import json
import pathlib
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

UA = "Mozilla/5.0 (compatible; PortfolioChecker/1.0)"


def fetch(url: str, retries: int, delay: int):
    """返回 (status, text)。只有 200 才认为成功。"""
    last = 0
    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=30) as resp:
                raw = resp.read()
                return resp.status, raw.decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            last = e.code
        except Exception:
            last = 0
        if attempt < retries:
            print(f"      ... 第 {attempt} 次失败（{last}），{delay}s 后重试")
            time.sleep(delay)
    return last, ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--retries", type=int, default=6)
    ap.add_argument("--delay", type=int, default=20)
    args = ap.parse_args()

    cfg = json.loads(pathlib.Path(args.config).read_text(encoding="utf-8"))
    base = cfg["base"]
    if "<owner>" in base:
        sys.exit("[配置] 请先把 base 里的 <owner>/<repo> 换成真实值")

    redline = cfg.get("redline", [])
    pages = cfg["pages"]
    failures = []

    # ---- 1. 着陆页可达性由 pages 列表覆盖；这里额外确认站点根 200
    print(f"== 站点根 ==")
    status, _ = fetch(base, args.retries, args.delay)
    print(f"   {status}  {base}")
    if status != 200:
        failures.append(f"站点根非 200：{status}")

    # ---- 2. 逐页断言
    print(f"\n== 页面断言（{len(pages)} 页）==")
    for page in pages:
        rel = page["path"]
        label = page.get("label", rel)
        url = base + urllib.parse.quote(rel)
        status, text = fetch(url, args.retries, args.delay)

        problems = []
        if status != 200:
            problems.append(f"HTTP {status}")

        for kw in page.get("must", []):
            if kw not in text:
                problems.append(f"缺少必须文本：{kw!r}")
        for kw in page.get("mustNot", []):
            if kw in text:
                problems.append(f"出现禁止文本：{kw!r}")

        hits = [w for w in redline if w and w in text]
        if hits:
            problems.append(f"红线命中：{hits}")

        if problems:
            failures.append(f"{label}（{rel}）：" + "；".join(problems))
            print(f"   FAIL  {label}")
            for p in problems:
                print(f"         - {p}")
        else:
            print(f"   PASS  {label}  ({len(text)} 字符)")

    # ---- 3. 汇总
    print("\n== 结果 ==")
    if failures:
        print(f"❌ {len(failures)} 项失败")
        for f in failures:
            print("   -", f)
        return 1
    print(f"✅ 全部通过（{len(pages)} 页 + 站点根）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
