#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
脱敏红线扫描：把"整站不该出现的词"固化成一份可复用的词表，交给脚本机械判定。

为什么必须做成脚本
    靠人"看一遍"是概率性检查 —— 同一个词这次看到、下次漏掉。
    脚本扫的是**全文件**（含 <title>、HTML 注释、JS 字符串），
    而肉眼和页面快照只能看到渲染后的正文，会漏掉一大半。

用法
    # 1) 复制词表模板，填自己的词
    cp redline.words.txt redline.words.txt   # 已随包提供模板，直接编辑
    # 2) 扫描
    python3 scan_redline.py --words redline.words.txt --dir ~/Documents/<站点目录>

    # 只扫某些扩展名 / 排除目录
    python3 scan_redline.py --words redline.words.txt --dir <站点目录> \
        --ext .html,.md,.js,.json --exclude .git,node_modules

退出码
    0 零命中（可以发布） / 1 有命中（禁止发布） / 2 参数错误
"""

import argparse
import pathlib
import re
import sys

DEFAULT_EXT = (
    ".html", ".htm", ".md", ".txt", ".js", ".mjs", ".cjs", ".css", ".json",
    ".xml", ".yml", ".yaml", ".py", ".sh", ".toml", ".ini", ".cfg", ".env",
)
DEFAULT_EXCLUDE = (".git", "node_modules", "__pycache__", ".idea", ".vscode")


def load_words(path: pathlib.Path):
    """词表格式：一行一个词；# 开头为注释；空行忽略。支持一行多词（用 | 分隔）。"""
    words = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        for w in line.split("|"):
            w = w.strip()
            if w:
                words.append(w)
    return words


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--words", required=True, help="词表文件")
    ap.add_argument("--dir", required=True, help="待扫描目录")
    ap.add_argument("--ext", default=",".join(DEFAULT_EXT), help="扫描的扩展名，逗号分隔")
    ap.add_argument("--exclude", default=",".join(DEFAULT_EXCLUDE), help="排除的目录名，逗号分隔")
    ap.add_argument("--show-ok", action="store_true", help="打印每个文件的通过状态")
    args = ap.parse_args()

    root = pathlib.Path(args.dir).expanduser().resolve()
    wpath = pathlib.Path(args.words).expanduser()
    if not root.is_dir():
        sys.exit(f"[参数] 目录不存在：{root}")
    if not wpath.exists():
        sys.exit(f"[参数] 词表不存在：{wpath}")

    words = load_words(wpath)
    if not words:
        sys.exit("[词表] 没有任何词 —— 空词表会给出虚假的安全感，请先填写")

    exts = tuple(e if e.startswith(".") else "." + e for e in args.ext.split(",") if e.strip())
    excludes = tuple(x.strip() for x in args.exclude.split(",") if x.strip())

    # 长词优先匹配，避免短词把长词切碎后漏报
    words.sort(key=len, reverse=True)
    pattern = re.compile("|".join(re.escape(w) for w in words))

    files = []
    for p in sorted(root.rglob("*")):
        if any(part in excludes for part in p.relative_to(root).parts):
            continue
        if p.is_file() and p.suffix.lower() in exts:
            files.append(p)

    print(f"词表：{len(words)} 个词   扫描：{len(files)} 个文件   目录：{root}\n")

    hits = []
    for p in files:
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except Exception as e:
            print(f"   [读取失败] {p.relative_to(root)}  ({e})")
            continue
        local = []
        for lineno, line in enumerate(text.splitlines(), 1):
            for m in pattern.finditer(line):
                local.append((lineno, m.group(0), line.strip()[:110]))
        rel = p.relative_to(root)
        if local:
            hits.extend((rel, ln, w, snip) for ln, w, snip in local)
            print(f"   ❌ {rel}  —— {len(local)} 处")
            for ln, w, snip in local[:5]:
                print(f"        L{ln}  [{w}]  {snip}")
            if len(local) > 5:
                print(f"        ... 其余 {len(local) - 5} 处")
        elif args.show_ok:
            print(f"   ✅ {rel}")

    print()
    if hits:
        print(f"❌ 共 {len(hits)} 处命中，禁止发布。逐条处理后重跑。")
        return 1
    print(f"✅ 零命中，{len(files)} 个文件全部通过。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
