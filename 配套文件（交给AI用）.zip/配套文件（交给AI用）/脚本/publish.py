#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GitHub Pages 整体发布脚本（Git Data API，单次干净提交）

用途
    把本地一个目录整体同步到某个 GitHub 仓库的指定分支，
    只产生 **1 条提交**（不是 N 个文件 N 条提交），适合作品集站这种"全量替换"场景。

为什么不用 git push
    ① 本地目录不需要是 git 仓库，零配置；
    ② 不会把删掉的文件留在历史里（tree 无 base_tree = 全量替换）；
    ③ 单条提交信息干净，不会把敏感词写进 diff。

用法
    python3 publish.py --owner <用户名> --repo <仓库名> --dir <本地目录> \
                       --message "提交信息" [--branch main] [--dry-run]

凭据（三选一，按优先级）
    1) 环境变量 GITHUB_TOKEN
    2) 环境变量 GH_TOKEN
    3) ~/.git-credentials 里的 https://<user>:<token>@github.com 行
    脚本全程不打印 token。

退出码
    0 成功 / 1 参数或凭据错误 / 2 GitHub API 报错
"""

import argparse
import base64
import json
import os
import pathlib
import re
import sys
import urllib.error
import urllib.request

API = "https://api.github.com"

# 永远不上传的东西
SKIP_DIR_NAMES = {".git", ".github", "__pycache__", "node_modules", ".idea", ".vscode"}
SKIP_FILE_NAMES = {".DS_Store", "Thumbs.db", "desktop.ini"}
# 反向说明：图片、PDF 等二进制文件也可以上传，脚本按 base64 统一处理。


# ---------------------------------------------------------------- 凭据
def load_token() -> str:
    for key in ("GITHUB_TOKEN", "GH_TOKEN"):
        val = os.environ.get(key)
        if val and val.strip():
            return val.strip()

    cred = pathlib.Path.home() / ".git-credentials"
    if not cred.exists():
        sys.exit("[凭据] 未设置 GITHUB_TOKEN，且 ~/.git-credentials 不存在")
    for line in cred.read_text(encoding="utf-8", errors="ignore").splitlines():
        m = re.match(r"https://[^:]+:([^@]+)@github\.com", line.strip())
        if m:
            return m.group(1)
    sys.exit("[凭据] ~/.git-credentials 中没有 github.com 条目")


# ---------------------------------------------------------------- HTTP
def req(method: str, url: str, token: str, body=None):
    data = json.dumps(body).encode("utf-8") if body is not None else None
    r = urllib.request.Request(url, data=data, method=method)
    r.add_header("Authorization", f"Bearer {token}")
    r.add_header("Accept", "application/vnd.github+json")
    r.add_header("X-GitHub-Api-Version", "2022-11-28")
    if data is not None:
        r.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(r, timeout=60) as resp:
            raw = resp.read()
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:800]
        sys.exit(f"[API] {method} {url}\n  -> HTTP {e.code}\n  {detail}")
    except urllib.error.URLError as e:
        sys.exit(f"[网络] {method} {url}\n  -> {e.reason}")


# ---------------------------------------------------------------- 文件收集
def collect(root: pathlib.Path):
    root = root.resolve()
    items = []
    for p in sorted(root.rglob("*")):
        if any(part in SKIP_DIR_NAMES for part in p.relative_to(root).parts):
            continue
        if p.is_dir() or p.name in SKIP_FILE_NAMES:
            continue
        items.append((p.relative_to(root).as_posix(), p))
    return items


# ---------------------------------------------------------------- 主流程
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--owner", required=True, help="GitHub 用户名或组织名")
    ap.add_argument("--repo", required=True, help="仓库名")
    ap.add_argument("--dir", required=True, help="本地目录")
    ap.add_argument("--message", required=True, help="提交信息")
    ap.add_argument("--branch", default="main")
    ap.add_argument("--dry-run", action="store_true", help="只列出将上传的文件，不写入")
    ap.add_argument("--no-nojekyll", action="store_true",
                    help="默认会补一个空 .nojekyll（禁用 Jekyll，避免下划线目录被吞）；加此参数则跳过")
    args = ap.parse_args()

    root = pathlib.Path(args.dir).expanduser()
    if not root.is_dir():
        sys.exit(f"[参数] 目录不存在：{root}")

    items = collect(root)
    if not items:
        sys.exit(f"[参数] 目录为空：{root}")

    if not args.no_nojekyll and not any(name == ".nojekyll" for name, _ in items):
        items.append((".nojekyll", None))

    print(f"== 待发布 {len(items)} 个文件 ==")
    for name, _ in items[:25]:
        print("   ", name)
    if len(items) > 25:
        print(f"    ... 其余 {len(items) - 25} 个")

    if args.dry_run:
        print("\n[dry-run] 未写入任何内容")
        return 0

    token = load_token()

    # 1) 读当前分支 HEAD 作为 parent（保证 fast-forward，无需强推）
    ref = req("GET", f"{API}/repos/{args.owner}/{args.repo}/git/ref/heads/{args.branch}", token)
    parent = ref["object"]["sha"]
    print(f"\n当前 {args.branch} HEAD = {parent[:10]}")

    # 2) 每个文件建一个 blob
    tree = []
    for idx, (name, path) in enumerate(items, 1):
        content = path.read_bytes() if path is not None else b""
        blob = req("POST", f"{API}/repos/{args.owner}/{args.repo}/git/blobs", token, {
            "content": base64.b64encode(content).decode("ascii"),
            "encoding": "base64",
        })
        tree.append({"path": name, "mode": "100644", "type": "blob", "sha": blob["sha"]})
        if idx % 20 == 0 or idx == len(items):
            print(f"   blob {idx}/{len(items)}")

    # 3) 建 tree —— 关键：不传 base_tree，等于整棵树全量替换
    new_tree = req("POST", f"{API}/repos/{args.owner}/{args.repo}/git/trees", token,
                   {"tree": tree})

    # 4) 建 commit
    commit = req("POST", f"{API}/repos/{args.owner}/{args.repo}/git/commits", token, {
        "message": args.message,
        "tree": new_tree["sha"],
        "parents": [parent],
    })

    # 5) 移动分支指针
    req("PATCH", f"{API}/repos/{args.owner}/{args.repo}/git/refs/heads/{args.branch}", token,
        {"sha": commit["sha"]})

    print(f"\n✅ 已发布  commit {commit['sha'][:10]}  ({len(items)} 个文件)")
    print(f"   线上地址  https://{args.owner}.github.io/{args.repo}/")
    print("   首次部署 / 大改动后 CDN 生效约 40-60s，稍等再访问")
    return 0


if __name__ == "__main__":
    sys.exit(main() or 0)
